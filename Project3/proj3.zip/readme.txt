README FOR PROJECT 3:  RSA


references:
    - isPrime method taken from a stackerflow.com post
  

->The prime numbers have to be put in by the user (no random primes)

->The user uses the program from the top button to the bottom button.


