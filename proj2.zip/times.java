/* Authors: Mike McClory and Mohammed Hasan
 * Class: CS342 Software Design
 * Instructor: P.Troy
 * Project 2: Minesweeper
 * 
 * Conatins: Game class (for the menu items ) 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * */  


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;



   //
   // class for the objects that hold info for the "top-ten" option
   //
   class times extends GameMenu
   {
     private static String name; // name of player
     private static int time;   // time player won game in
     
     
     // class constructor that initializes scores object
     public times()
     { 
        name = "";  
        time = 0;
     }
     
     public times(int x)
     {
       
     }
     
     // sets scores object with information from a file
     public void setTimes(String s, int x)
     {
       name = s;
       time = x;
     }
       
       
     // returns the name from a scores object
     public String getName()
     { 
       return name; 
     }  
       
       
     // returns the score from a scores object
     public int getTime()
     {
       return time;     
     }
     
     
    
  
  

     
   }// end of times class
   
   
   
   