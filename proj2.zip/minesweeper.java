/* Authors: Mike McClory and Mohammed Hasan
 * Class: CS342 Software Design
 * Instructor: P.Troy
 * Project 2: Minesweeper
 * 
 * Conatins: Main Souce Code 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.*;
import java.io.*;
import javax.swing.KeyStroke;



public class minesweeper extends JFrame implements ActionListener
{ 
   // all the items that make up the game
   static minesweeper app;
   static JFrame frame = new JFrame("Minesweeper");
   private MyJButton buttons[][]; // 2d-array of buttons
   private Container container; // the container the grid of buttons will lie in
   private GridLayout grid1, grid;
   private MyJButton reset;
   private JLabel mineCount = new JLabel();
   private JLabel timer = new JLabel();
   JMenuBar menuBar = new JMenuBar();
   JMenu game = new JMenu("Game");
   JMenu menuHelp = new JMenu("Help");
   JMenuItem exit = new JMenuItem("Exit", KeyEvent.VK_X); 
   JMenuItem menuReset = new JMenuItem("Reset",KeyEvent.VK_R);
   JMenuItem topTen = new JMenuItem("Top Ten",KeyEvent.VK_T);
   JMenuItem help = new JMenuItem("Help",KeyEvent.VK_L);
   JMenuItem about = new JMenuItem("About",KeyEvent.VK_A);
   static int mines = 10;
   static boolean isFirstClick = true; 
  // Timer timeClock = new Timer();
   static int delay = 1000;
   static int spacesDisabled = 0;
   static int timeElapsed = 0;
   static boolean gaming;      //Toggle if the game operation is allowed
   Game g = new Game();
   GameMenu gm = new GameMenu();
   
   
   // set up GUI
   public minesweeper(JFrame frame)
   {
      super( "Minesweeper" );
      
      // add menu bar and its items to gui
      menuBar.add(game);
      menuBar.add(menuHelp);
      exit.addActionListener(this);
      menuReset.addActionListener(this);
      topTen.addActionListener(this);
      help.addActionListener(this);
      about.addActionListener(this);
      game.add(menuReset);
      game.add(topTen);
      game.add(exit);
      menuHelp.add(about);
      menuHelp.add(help);
      frame.setJMenuBar(menuBar);
      
      // set up layouts
      grid1 = new GridLayout( 10, 10, 1, 1);

      
      // get content pane and set its layout
      container = getContentPane();
      container.setLayout( grid1 );
      container.setSize(300, 300);
      
      // create and add buttons
      buttons = new MyJButton[10][10];
      
      for ( int count = 0; count < 10; count++ ) 
      {
        String row = String.valueOf(count);
        for(int j=0;j<10;j++)
        {
          String col = String.valueOf(j);
          String s = ""; //row.concat("     ").concat(col);
          buttons[count][j] = new MyJButton(s);
          buttons[count][j].setNumbers(count,j);
          
          buttons[count][j].setPreferredSize(new Dimension(30, 30));
          buttons[count][j].addMouseListener(new MouseHandler());
          buttons[count][j].addActionListener(this);
          
          
          container.add( buttons[count][j] );
          
        }
      }
      
      // create and add timer to gui
      timer.setText("        Time (in secs): \n" + timeElapsed);
      timer.setFont(new Font("Arial",Font.BOLD , 16));
      timer.setPreferredSize(new Dimension(250,200));
      frame.add(timer,BorderLayout.WEST);
     
      
      // add the button grid to the gui
      frame.add(container,BorderLayout.SOUTH);
      
      // add reset button to the gui
      reset = new MyJButton("RESET");
      reset.setNumbers(-1,-1);
      reset.setFont(new Font("Arial",Font.BOLD , 20));
      reset.addMouseListener( new MouseHandler() );
      reset.setPreferredSize(new Dimension(100,25));
      frame.add(reset, BorderLayout.CENTER);

      // create and add mine counter to gui
      mineCount.setText("                 Mines Left: " + mines); 
      mineCount.setFont(new Font("Arial",Font.BOLD , 16));
      mineCount.setPreferredSize(new Dimension(250,200));
      frame.add(mineCount,BorderLayout.EAST);
      
      
   } // end constructor GridLayoutDemo

   
  // 
  // handles JMenuItem actions from the "Game" and "Help" menus
  // 
  public void actionPerformed (ActionEvent e)
  {
    GameMenu gm = new GameMenu();
    Object item;
    item = e.getSource(); // get menu item that triggered the event
    
    
    // match the menu item to the its resulting action
    if(item == menuReset)
    {
         mineCount.setText("                 Mines Left: " + mines); 
         resetGame();
    }
    else if(item == topTen)
    {    
       try
       {
         gm.displayTopTen();
       }
       catch(FileNotFoundException fnf)
       {
         JOptionPane.showMessageDialog(null, "An ERROR has occurred while reading from file.\n\n");
       }
       
    } 
    else if(item == exit) 
    {
           System.exit(0);
    }
    else if(item == about)
    {
         gm.displayAbout();
    }
    else if(item == help)
    {
         gm.displayHelp();    
    }
    
   } // end of action performed
   

   
   public static void main( String args[] )
   {
      
      frame.setSize(670,400);
      frame.setLayout(new BorderLayout());
     
      gaming = true;
      
      //create board and start the gui
      app = new minesweeper(frame);
      app.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
      
      
      frame.setVisible(true);
        
   } // end of main


 
   public void resetGame()
   //Restart a new game
   {
        
        g = new Game();
        gaming = true;

        mines = 10;
        mineCount.setText("                 Mines Left: " + mines); 
        
        timeElapsed = 0;
        isFirstClick = true;
        
        timer.setText("        Time (in secs): \n" + timeElapsed);
        
        
        for(int i=0;i<10;i++)
        {
            for(int j=0;j<10;j++)
            {
                buttons[i][j].setText("");
                buttons[i][j].getModel().setPressed(false);
            }
        }

       
    }
    
    
    
//
// handles mouse click events
//
class MouseHandler extends MouseAdapter 
{
   
  public void mouseClicked (MouseEvent e)
  {
    String s = "";
    MyJButton temp = (MyJButton) e.getSource();
   
    
    // check if its the first click from the user on the board
    if((isFirstClick) && (temp.getRowNum() != -1 ))
    {
       new Reminder(1);
       isFirstClick = false;
       
    }
    
    
    if(temp.getText().equals("RESET"))
        resetGame();
    
    
    if ( (gaming == true) && (SwingUtilities.isLeftMouseButton(e)) )
    {
      
      if(g.leftClick(temp.getRowNum(),temp.getColNum()))
      {
               JOptionPane.showMessageDialog(null, "You lose");
                  //Do sth here to show the mines
                   gaming = false;
                  
                   
      }
      
   
      if(g.getUncleared() == 10)
         //Win the game
      {
         JOptionPane.showMessageDialog(null, "You win");
         gaming = false;
        
         
         try
         {
           gm.writeToFile(timeElapsed);
         }
         catch(FileNotFoundException fnf)
         {
           JOptionPane.showMessageDialog(null,"File not found.");
         }
         
      }
      
      for(int i=0;i<10;i++)
        for(int j=0;j<10;j++)
      {
        if(g.blocks[i][j].checkCleared())
        {
           if(buttons[i][j].getModel().isPressed() == false)
              buttons[i][j].getModel().setPressed(true);
             
           
           int n = g.blocks[i][j].getNumMines();
           buttons[i][j].setText(n + "");
        }
      }
    }
    else if ( (gaming == true) && (SwingUtilities.isRightMouseButton(e)) )
    {  
      if(temp.getText().equals(""))
      {
        
        if(mines > 0)
           temp.setText("M");
        
        mines--;
        
        if(mines <0)
        {
          mines = 0;
        }
          
        mineCount.setText("                 Mines Left: " + mines); 
      }
      
      else if(temp.getText().equals("M"))
      {
        temp.setText("?");
        
        mines++;
        mineCount.setText("                 Mines Left: " + mines); 
      }
      
      else if(temp.getText().equals("?"))
      {
        temp.setText("");
      }
      
      
     }   
  } // end mouseClicked
  
  
}// end mouseHandler class



//
// class for keeping track of the time elapsed
//
public class Reminder 
{
   Timer timeClock = new Timer();

  public Reminder(int seconds) 
  {
          timeClock.schedule(new RemindTask(),0, 1*1000);
  }

    class RemindTask extends TimerTask 
    {
        public void run() 
        {
          if(gaming == true)
          {
            timeElapsed++;
            timer.setText("        Time (in secs): \n" + timeElapsed);
          } 
            
        }
       
    }
 }// end of Reminder class


} // end class minesweeper



