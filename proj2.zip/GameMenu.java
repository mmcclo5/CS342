/* Authors: Mike McClory and Mohammed Hasan
 * Class: CS342 Software Design
 * Instructor: P.Troy
 * Project 2: Minesweeper
 * 
 * Conatins: Game class (for the menu items ) 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

//
// class that contains the functions for the Game Menu's options
// i.e. help, about, top ten
//
public class GameMenu
{
 
  static times[] t = new times[15];
  
 
  //
  // display the about page
  //
  public void displayAbout() 
  {
    JOptionPane.showMessageDialog(null,"                        ABOUT Minesweeper \n\n"
                                     + "Created by Mike McClory and Mohammed Hasan.\n\n"
                                     + "Created for CS342: Software Design with Prof. Troy.        \n\n");
    
    
    
  } // end of displayAbout
  
  
  
  //
  // display the help page
  //
  public void displayHelp()
  {
    JOptionPane.showMessageDialog (null, "                                              HELP CENTER\n\n "
                                       + "Left-click a square to find out if it is a mine or not.\n\n" 
                                       + "Right-click a square once to tag it as definitley holding a mine.\n\n" 
                                       + "Right-click a square a second time to tag it as maybe having a mine.\n\n"
                                       + "Right-click a square a third time will make the square look like you didn't touch it.        \n");
    
    
  
  } // end of displayHelp
  
  
  
  
  //
  // reads from the file and displays the top ten scores
  //
  public void displayTopTen() throws FileNotFoundException
  {

    // read from file
    readFromFileAndDisplay();
    
    
  } // end of displayTopTen
  
  
  static int j = 0;
  static int k = 0;
  static int n = 1;
  
  
  
  //
  // reads information from a file
  //
  public void readFromFileAndDisplay() throws FileNotFoundException
  {
    
    String line;
    File file = new File("topTen.txt");
    Scanner sc;
    
    // check whether file exists or not
    if(file.exists())
       sc = new Scanner(file);    
    else
       sc = new Scanner(new File("topTen.txt"));

     String[] words = new String[10];
    
    // read file line-by-line, parse into words and put into array of strings
    while((line = sc.nextLine()) != null) 
    {
      words[j] = line;
      j++;
      
      if(!sc.hasNextLine())
      { 
        JOptionPane.showMessageDialog(null, "NAME" + "          TIME\n"
                                            + words[0] + "\n"
                                            + words[1] + "\n"
                                            + words[2] + "\n"
                                            + words[3] + "\n"
                                            + words[4] + "\n"
                                            + words[5] + "\n"
                                            + words[6] + "\n"
                                            + words[7] + "\n" );
                                        
                                        
        return;
      }   
    }
  
    
  } // end of readFromFile
  
  
  
  //
  // wirte a score to the top ten file
  //
  public void writeToFile(int time) throws FileNotFoundException
  {
    String name = JOptionPane.showInputDialog("Enter your first name: ");
    JOptionPane.showMessageDialog(null,name);
    File file;
    
    file = new File("topTen.txt");
    Scanner sc;
    
    // check whether file exists or not
    if(!file.exists())
       file = new File("topTen.txt");
    
    try
    {
      FileWriter fWriter = new FileWriter (file);
      PrintWriter pWriter = new PrintWriter (fWriter);
      pWriter.print(name + "            ");
      pWriter.println (time + "");
      pWriter.close();
    }
    catch(IOException e)
    {
      JOptionPane.showMessageDialog(null,"File not found.");
    }
    
    
    
    
    
    
    
  } // end of writeToFile
  
  
  
     //
     // sorts the array of scores
     //
     public void sortArray(times scores[])
     {
       times tmp = new times();
       
       System.out.println("in sort...... " +  " " + scores[0].getTime());
       
        boolean swapped = true;
        int j = 0;
      
       while (swapped) 
       {
         swapped = false;
         j++;
        
         for (int i = 0; i < scores.length - j; i++) 
         {
           if(scores[i] != null)
             System.out.println("in sort: " +  i + " " + scores[0].getTime());
          
           if(scores[i+1] != null)
           {
           if (scores[i].getTime() > scores[i + 1].getTime()) 
            {
                tmp = scores[i];
                scores[i] = scores[i + 1];
                scores[i + 1] = tmp;
                swapped = true;
            }
          }
        }
       }
       
     } // end of sortArray  
     
     
     
      //
     // prints the top-ten scores
     //
     public void printScores()
     {
         
                                           
    
     }
     
     
} // end of GameMenu class




