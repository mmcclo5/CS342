/* Authors: Mike McClory and Mohammed Hasan
 * Class: CS342 Software Design
 * Instructor: P.Troy
 * Project 2: Minesweeper
 * 
 * Conatins: MyJButton Class for the minesweeper buttons 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * */


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class MyJButton extends JButton 
{
  private int rowNum;
  private int colNum;
  boolean isMine = false;
  
  
  // sets the text the button will start with if any
  public MyJButton ( String text )
  {
    super (text);
    
  }
  
  
  // set the row and column numbers for the button
  public void setNumbers (int x, int y)
  {
    rowNum = x;
    colNum = y;
  }
  
  
  // get the number of the row the button is in
  public int getRowNum ()
  {
    return rowNum;
  }
  
  
  // get the number of the column the button is on
  public int getColNum()
  {
    return colNum;  
  }
  
  

}











